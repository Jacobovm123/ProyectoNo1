﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HombresDeNegocios.BaseDatos;

namespace HombresDeNegocios.Controllers
{
    public class EventsController : Controller
    {
        private Retranca_AnalisisEntities db = new Retranca_AnalisisEntities();

        // GET: Events
        public ActionResult Index()
        {
            var events = db.Events.Include(e => e.Chapter);
            return View(events.ToList());
        }

        // GET: Events/Details/5
        public ActionResult Details(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = db.Events.Find(id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);
        }

        // GET: Events/Create
        public ActionResult Create()
        {
            var templateList = db.Event_Template.ToList();
            var templateItem = templateList.FirstOrDefault();
            ViewBag.Id_Chapter = new SelectList(db.Chapters, "Id_Chapter", "Name");
            ViewBag.Template = templateItem;
            return View();
        }

        // POST: Events/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id_Event,Id_Chapter,Address,Minimum_Dishes,Previous_Balance,Amount_Attendance,Amount_Offering,Amount_Special_Offering,Credit_Amount,Total_Amount,Payment_Discharge,Current_Balance")] Event @event)
        {
            if (ModelState.IsValid)
            {
                @event.Date = DateTime.Today;
                db.Events.Add(@event);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Id_Chapter = new SelectList(db.Chapters, "Id_Chapter", "Name", @event.Id_Chapter);
            return View(@event);
        }

        // GET: Events/Edit/5
        public ActionResult Edit(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = db.Events.Find(id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            ViewBag.Id_Chapter = new SelectList(db.Chapters, "Id_Chapter", "Name", @event.Id_Chapter);
            return View(@event);
        }

        // POST: Events/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id_Event,Id_Chapter,Date,Address,Minimum_Dishes,Previous_Balance,Amount_Attendance,Amount_Offering,Amount_Special_Offering,Credit_Amount,Total_Amount,Payment_Discharge,Current_Balance")] Event @event)
        {
            if (ModelState.IsValid)
            {
                db.Entry(@event).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id_Chapter = new SelectList(db.Chapters, "Id_Chapter", "Name", @event.Id_Chapter);
            return View(@event);
        }

        // GET: Events/Delete/5
        public ActionResult Delete(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = db.Events.Find(id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);
        }

        // POST: Events/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(long id)
        {
            Event @event = db.Events.Find(id);
            db.Events.Remove(@event);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
