﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HombresDeNegocios.BaseDatos;

namespace HombresDeNegocios.Controllers
{
    public class Event_AttendanceController : Controller
    {
        private Retranca_AnalisisEntities db = new Retranca_AnalisisEntities();

        // GET: Event_Attendance
        public ActionResult Index()
        {
            var event_Attendance = db.Event_Attendance.Include(e => e.Event).Include(e => e.Event_Fee_Type).Include(e => e.Person).Include(e => e.Payment_Type1);
            return View(event_Attendance.ToList());
        }

        // GET: Event_Attendance/Details/5
        public ActionResult Details(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event_Attendance event_Attendance = db.Event_Attendance.Find(id);
            if (event_Attendance == null)
            {
                return HttpNotFound();
            }
            return View(event_Attendance);
        }

        // GET: Event_Attendance/Create
        public ActionResult Create(long? id)
        {
          
            ViewBag.Id_Event = new SelectList(db.Events, "Id_Event", "Address");
            ViewBag.Id_Event_Fee_Type = new SelectList(db.Event_Fee_Type, "Id_Event_Fee", "Description");

            ViewBag.Payment_Type = new SelectList(db.Payment_Type, "Id_Payment_Type", "Nombre");
            if (id != null)
            {
                var people = db.People.Find(id);
                ViewBag.Id_Person = new List<SelectListItem>
                {
                    new SelectListItem() { Text = people.Names, Value = people.Id_Person.ToString() }
                };
            }
            else
            {
                ViewBag.Id_Person = new SelectList(db.People, "Id_Person", "Names");

            }
            return View();
        }

        // POST: Event_Attendance/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id_Event_Attendance,Id_Event,Id_Person,Id_Event_Fee_Type,Amount_Fee,Payment_Type,Special_Offering,Special_Offering_Description")] Event_Attendance event_Attendance)
        {
            if (ModelState.IsValid)
            {
                db.Event_Attendance.Add(event_Attendance);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Id_Event = new SelectList(db.Events, "Id_Event", "Address", event_Attendance.Id_Event);
            ViewBag.Id_Event_Fee_Type = new SelectList(db.Event_Fee_Type, "Id_Event_Fee", "Description", event_Attendance.Id_Event_Fee_Type);
            ViewBag.Id_Person = new SelectList(db.People, "Id_Person", "Names", event_Attendance.Id_Person);
            ViewBag.Payment_Type = new SelectList(db.Payment_Type, "Id_Payment_Type", "Nombre", event_Attendance.Payment_Type);
            return View(event_Attendance);
        }

        // GET: Event_Attendance/Edit/5
        public ActionResult Edit(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event_Attendance event_Attendance = db.Event_Attendance.Find(id);
            if (event_Attendance == null)
            {
                return HttpNotFound();
            }
            ViewBag.Id_Event = new SelectList(db.Events, "Id_Event", "Address", event_Attendance.Id_Event);
            ViewBag.Id_Event_Fee_Type = new SelectList(db.Event_Fee_Type, "Id_Event_Fee", "Description", event_Attendance.Id_Event_Fee_Type);
            ViewBag.Id_Person = new SelectList(db.People, "Id_Person", "Membership_Id", event_Attendance.Id_Person);
            ViewBag.Payment_Type = new SelectList(db.Payment_Type, "Id_Payment_Type", "Nombre", event_Attendance.Payment_Type);
            return View(event_Attendance);
        }

        // POST: Event_Attendance/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id_Event_Attendance,Id_Event,Id_Person,Id_Event_Fee_Type,Amount_Fee,Payment_Type,Special_Offering,Special_Offering_Description")] Event_Attendance event_Attendance)
        {
            if (ModelState.IsValid)
            {
                db.Entry(event_Attendance).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id_Event = new SelectList(db.Events, "Id_Event", "Address", event_Attendance.Id_Event);
            ViewBag.Id_Event_Fee_Type = new SelectList(db.Event_Fee_Type, "Id_Event_Fee", "Description", event_Attendance.Id_Event_Fee_Type);
            ViewBag.Id_Person = new SelectList(db.People, "Id_Person", "Membership_Id", event_Attendance.Id_Person);
            ViewBag.Payment_Type = new SelectList(db.Payment_Type, "Id_Payment_Type", "Nombre", event_Attendance.Payment_Type);
            return View(event_Attendance);
        }

        // GET: Event_Attendance/Delete/5
        public ActionResult Delete(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event_Attendance event_Attendance = db.Event_Attendance.Find(id);
            if (event_Attendance == null)
            {
                return HttpNotFound();
            }
            return View(event_Attendance);
        }

        // POST: Event_Attendance/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(long id)
        {
            Event_Attendance event_Attendance = db.Event_Attendance.Find(id);
            db.Event_Attendance.Remove(event_Attendance);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
